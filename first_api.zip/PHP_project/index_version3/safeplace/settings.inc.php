<?php

define('DEBUG', true);
define('MODULES_DIR', '../safeplace/');

$dbSettings = [
    'connectionString' => 'mysql:host=localhost;dbname=test;charset=utf8',
    'dbUser' => 'mysql',
    'dbPwd' => 'mysql'
];

